// #include <Rcpp.h>
// using namespace Rcpp;
//
// //
//
// // [[Rcpp::export]]
// double dist_rollmean(NumericVector alpha) {
//
//   Environment e = Environment::global_env();
//   Rcpp::NumericMatrix par = e["parf"];
//   Rcpp::NumericMatrix pc = e["pcf"];
//   Rcpp::NumericVector k = e["k"];
//   int window = e["window"];
//   int min = e["min"];
//   double pot = e["pot"];
//
//   int nrow = par.nrow(), ncol = par.ncol();
//   // int ncolt; // number of species with enough data for mean PoR values
//   Rcpp::NumericMatrix por(nrow, ncol);
//   Rcpp::NumericMatrix por_rm(nrow, ncol); // for the running mean
//   Rcpp::NumericVector porSel(nrow); // for the running mean
//   Rcpp::NumericMatrix ri(nrow, ncol);
//   Rcpp::NumericMatrix rii(nrow, ncol);
//   Rcpp::NumericMatrix riii(nrow, ncol);
//   Rcpp::NumericMatrix riiii(nrow, ncol);
//   Rcpp::NumericMatrix pornorm(nrow, ncol);
//   Rcpp::NumericVector vm = nrow;
//   Rcpp::NumericVector var = ncol;
//   Rcpp::NumericVector sd = ncol;
//   Rcpp::NumericVector sdw = ncol;
//   Rcpp::NumericVector vec = nrow;
//   Rcpp::NumericVector mcov = ncol; // mean cover of each species
//   Rcpp::NumericVector csum = ncol; // mean counts of each species
//
//   //
//   NumericVector rollmean(NumericVector x, int window, int min);
//
//   // ri - divide counts by PPE and K (= REVEALS step 1)
//   Rcpp::NumericVector f = alpha * k;
//
//   // loop samples
//   for (int i = 0; i < nrow; i++) {
//     ri(i,_) = pc(i,_) / f;
//
//   }
//
//
//   // calculate proportions 'rii' (= REVEALS step 2)
//   // loop samples
//   for (int i = 0; i < nrow; i++) {
//
//     // first calculate row sums (loop taxa)
//     double s = 0;
//     s = sum(ri(i,_));
//
//     // calculate proportions
//     rii(i,_) = 100 * ri(i,_) / s;
//   }
//
//   // calculate mean cover of each taxon 'mcov' (NA values are not considered)
//   // also add up counts for each taxon 'csum'
//   // loop taxa
//
//   // for (int j = 0; j < ncol; j++) {
//   //   csum(j) = sum(pc(_,j));
//   //   mcov(j) = mean(rii(_,j));
//   // }
//
//   // calculate PoR ratio as pollen accumulation rate 'par' divided by cover 'rii'
//   // loop taxa
//   for (int j = 0; j < ncol; j++) {
//     por(_,j) = par(_,j) / rii(_,j);
//   }
//
//   NumericVector s, t;
//
//   // calculate running mean
//   for (int j = 0; j < ncol; j++) {
//     s = por(_,j);
//     por_rm(_,j) = rollmean(s, window, min);
//   }
//
//
//   // varsum1: variance  divided by mean PoR ratio)
//   // for (int j = 0; j < ncol; j++) {
//   //   s = por_rm(_,j);
//   //   t = na_omit(s);
//   //   double m = mean(t);
//   //   sd(j) = Rcpp::var(t) / m;
//   // }
//
//   // Alternative
//   // it seems that squares of the deviation from mean is not ideal
//   // therefore the attempt to alternatively use the potenz??? of the deviation
//   for (int j = 0; j < ncol; j++) {
//     t = na_omit(por_rm(_,j));
//     double m = mean(t);
//     s = abs(pow(abs(t - m), pot));
//     var(j) = sum(s)/((s.length()-1) * m);
//   }
//
//
//   return(sum(var));
// }
//
//
//
//
// // [[Rcpp::export]]
// NumericVector rollmean(NumericVector x, int window, int min) {
//
//
//   // Environment e = Environment::global_env();
//   // Rcpp::NumericVector vwindow = e["vwindow"];
//
//   int n = x.size();
//   // int window = 5;
//   // int min = 3;
//
//   // Set res as a NumericVector of NAs with length n
//   NumericVector res(n, NumericVector::get_na());
//
//   // variables for values to be added (a) and substracted (b) from total
//   double a, b = 0;
//
//   // minimum number of true values in window that is not NA
//   // int window = vwindow[1];
//   // int min = vwindow[2];
//
//   // Sum the first window worth of values of x
//   double total = 0.0;
//   int c = 0;
//   for(int i = 0; i < window; i++) {
//     if (x[i]>0){
//       total += x[i];
//       c += 1;
//     }
//   }
//
//   // Rcout << "The value of total is " << total << std::endl;
//
//   // Treat the first case separately
//   // only calculate when there is at least x values
//   if(c > (min - 1) ){
//     res[window - 1] = total / c;
//   }
//
//
//   // Iteratively update the total and recalculate the mean
//   for(int i = window; i < n; i++) {
//
//     // check the value to be added
//     // if NA, then add zero and reduce counter by 1
//     if (x[i]>0) {
//       a = x[i];
//     } else {
//       a = 0;
//       c += -1;
//     }
//
//     // check the value to be substracted
//     // if NA, then substract zero and increase counter by 1
//     // this way, counter c will not get negativ
//     if (x[i-window]>0) {
//       b = x[i-window];
//     } else {
//       b = 0;
//       c += 1;
//     }
//
//
//     // Subtract the (i - window)th case, and add the ith case
//     total += - b + a;
//
//
//     // only calculate when there is at least x values
//     // otherwise res[i] remains NA
//     if(c > (min - 1)){
//       res[i] = total / c;
//     }
//   }
//
//   return res;
// }
