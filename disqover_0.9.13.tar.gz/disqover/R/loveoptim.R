#' LOVEoptim
#'
#' The LOVE model (LOcal Vegetation Estimates), introduced by Shinya Sugita
#' (2007), aims to translate pollen data from small sites into local
#' vegetation composition. The model assumes that pollen deposition in small
#' basins is composed of local pollen deposition from the nearby vegetation and
#' regional pollen deposition from farther away. A key assumption for the LOVE
#' model is that regional pollen deposition is uniform across a region.
#'
#' The present implementation of the LOVE model in R is based on equation 6 and
#' 7 from Sugita (2007), with three small adaptations. Pollen dispersal factors
#' g(z) are calculated using the ‘DispersalFactorK’ function from the ‘disqover’
#' R package. Regional vegetation estimates are calculated with the REVEALSinR
#' function, also from the ‘disqover’ R package. Finally, error estimates are
#' produced by repeated model runs, with random noise added in the regional and
#' local pollen counts and in the pollen productivity estimates during each run.
#' For further details, consult Theuerkauf & Couwenberg (2024).
#'
#' To estimate local vegetation composition, the LOVE model requires pollen
#' data from one small site and from a nearby large lake. Pollen deposition in
#' both the small and the large site should be exclusively
#' atmospheric, which means that the sites should not have major inflows. To
#' minimize any disturbing effects from the shore vegetation, the large lake
#' should be circular.
#'
#' The LOVEoptim function calculates local vegetation composition from one pair of
#' local and regional pollen data. Too apply LOVE for multiple samples, apply
#' LOVEoptim in a loop.
#'
#' Key parameters of LOVE application are 'relative pollen productivity
#' estimates' (known as PPEs or RPPs) to account for the differential pollen
#' productivity and the fall speed of pollen for each pollen taxon to account
#' for differential pollen dispersal. For the calculation of distance weighting
#' factors, a suitable dispersal model should be chosen.
#'
#'
#' @param pollenLoc a dataframe of the raw pollen counts from the small site.
#'   Counts are arranged with pollen taxa in columns and samples in rows.
#'   Taxon names cannot include spaces! For each pollen taxon, fallspeed and
#'   PPEs have to be provided in the parameters.
#' @param pollenReg a dataframe of the raw pollen counts from the large lake.
#'   Counts are arranged with pollen taxa in columns and samples in rows. The same
#'   taxa must be same as for the local data, ideally local and regional data are
#'   all included in the same dataframe (see example dataset LOVEexamplePollen)
#' @param lParams EDIT: a list of parameters needed for LOVEoptim application
#'   the fallspeed of pollen in m s-1 ('fallspeed'), relative pollen productivity
#'   estimates ('ppe') and their standard error ('ppe.error'). Pollen taxa are
#'   given in rows, parameters in columns. See example dataset 'LOVEexampleParams'.
#' @param dfRadii EDIT: dataframe describing ring sizes
#' @param maxRingLove maximum number of rings that is included in the calculations
#' @param repeats number of repeated model runs
#'
#' @return LOVEoptim returns 4 data frames that the reconstructed abundances and 2
#' data frames that are suited for evaluation.
#' @return ...Mean:	mean of the resulting cover estimates
#' @return ...Q10: 10\% quantile of the resulting cover estimates
#' @return ...Q90: 90\% quantile of the resulting cover estimates
#' @return ...SD: standard deviation of the resulting cover estimates
#' @return ...Outlier:	mean number of resulting cover values that are too small (<0) or too large (>1)
#' @return ...OutlierQuant: the number of resulting cover values that are too small (<0) or too large (>1),
#' but considering the 10\% and 90\% quantiles
#'
#'
#' @author Martin Theuerkauf <martin.theuerkauf@greifswaldmoor.de>
#' @references Sugita, S. (2007) Theory of quantitative reconstruction of vegetation II:
#'   all you need is LOVE. The Holocene 17, 243–257.
#'   https://doi.org/10.1177/0959683607075838
#'
#'   Theuerkauf, M., Couwenberg, J. (2024) LOVE is in in the R – Two R tools
#'   for local vegetation reconstruction. Quaternary.
#'
#' @examples \dontrun{
#' ## Example application with simulated data from Theuerkauf & Couwenberg (2024).
#' ## The dataset includes three part
#'
#' data(LOVEexamplePollen, package = "disqover") # pollen data
#' data(LOVEexampleParams, package = "disqover") # parameters
#' data(LOVEexampleRings, package = "disqover") #ring data
#'
#'
#' ## apply LOVEoptim...
#' dfResults <- LOVEoptim(pollenLoc = cbind(age = 1, LOVEexamplePollen['local',]),
#'       pollenReg = cbind(age = 1, LOVEexamplePollen['regional',]),
#'       lParams = LOVEexampleParams,
#'       dfRadii = LOVEexampleRings,
#'       maxRingLove = 35)
#' }
#'
#' @export


LOVEoptim <- function(pollenLoc, pollenReg, lParams, dfRadii, maxRingLove, repeats = 10){



  ################################################################################
  ### prepare variables
  ################################################################################

  # just rename
  vSampleLoc <- pollenLoc
  vSampleReg <- pollenReg

  # main results
  lResults <- list()
  nTaxa  <- length(vSampleLoc[,-1])
  nRings <- length(dfRadii$mean)

  if (maxRingLove >= nRings){
    stop('maxRingLove is too high!')
  }

  # a matrix for the bestmem values (optimized local cover)
  # mBestMem <- matrix(data = 0, ncol = nTaxa, nrow = maxRingLove)
  # colnames(mBestMem) <- names(vSampleLoc[,-1])
  # rownames(mBestMem) <- dfRadii$mean[1:maxRingLove]
  aBestMem <- array(data = 0, dim = c(nTaxa, maxRingLove, repeats))
  dimnames(aBestMem) <- list(lParams$ppes$Taxon, dfRadii$mean[1:maxRingLove],1:repeats)

  # a matrix for the resulting virtual pollen composition
  # mPoldepTotalPro <- matrix(data = 0, ncol = nTaxa, nrow = maxRingLove)
  # colnames(mPoldepTotalPro) <- names(vSampleLoc[,-1])
  # rownames(mPoldepTotalPro) <- dfRadii$mean[1:maxRingLove]
  aPoldepTotalPro <- array(data = 0, dim = c(nTaxa, maxRingLove, repeats))
  dimnames(aPoldepTotalPro) <- list(lParams$ppes$Taxon, dfRadii$mean[1:maxRingLove],1:repeats)

  # a matrix for the best value
  mBestValue <- matrix(data = 0, ncol = repeats, nrow = maxRingLove)
  colnames(mBestValue) <- 1:repeats
  rownames(mBestValue) <- dfRadii$mean[1:maxRingLove]


  ################################################################################
  ### prepare distance weighting factors
  ################################################################################

  mK <- calK(dfRadii = dfRadii, lParams = lParams)


  # hier sollte loop beginnen
  for (i in 1:repeats){


    ################################################################################
    ### apply REVEALS
    ################################################################################

    # calculate regional vegetation composition with REVEALS,
    # REVEALS will automatically add noise in the pollen data and in the PPEs
    # no repetitions (n=1 !) to produce more variable results
    cover.regio <- REVEALSinR(pollen = vSampleReg, params = lParams$ppes, dwm = lParams$dwm,
                              tBasin = lParams$tBasinRegional, dBasin = lParams$dBasinRegional,
                              n = 1, verbose = FALSE)

    # extract regional cover
    dfMeanCoverRegio <- as.data.frame(cover.regio[ , grepl("mean", names(cover.regio) )] / 100)


    ################################################################################
    ### add noise in local pollen counts and PPEs
    ################################################################################

    ppes <- disqover:::rnorm_reveals(length(lParams$ppes$ppe), lParams$ppes$ppe, lParams$ppes$ppe.error)
    vSampleLocRand <- rmultinom(1, sum(vSampleLoc[-1]), vSampleLoc[-1]/sum(vSampleLoc[-1]))
    vSampleLocRandPro <- (vSampleLocRand/sum(vSampleLocRand))[,1]


    #################################################################################
    ### loop rings
    #################################################################################
    # j = 35
    # loop until maxRingLove - 1 because otherwise no regional ring remains
    for (j in 1:(maxRingLove)) {

      # just some progress message
      cat('\rModel run:', i,' Radius:', dfRadii$inner[j], '-',dfRadii$outer[j],'\t')

      #  Step 1: produce a correction factor F by dividing the actual terrestrial
      #  area of each ring by the geometric ring area --> this is too account for
      #  areas with no vegetation cover, e.g. lakes
      #  the selection starts at j+1 because the jth ring belongs to the local part
      vFregional <- dfRadii$terrestrial[(j+1):nRings]/dfRadii$ring[(j+1):nRings]

      # Step 2: multiply the K factor with the reconstructed regional cover of
      # each species and by pollen productivity (by columns) and by the
      # correction factor f (by rows)
      dfCoverxPPE <- unlist(dfMeanCoverRegio) * lParams$ppes$ppe
      mPoldepRegio <- t(t(mK[(j+1):nRings,]) * dfCoverxPPE) * vFregional
      vPoldepRegio = colSums(mPoldepRegio)

      # prepare F factor for 'local' rings
      vFlocal <- dfRadii$terrestrial[1:j]/dfRadii$ring[1:j]

      # extract local K factors
      mKlocal = mK[1:j,]

      # call the target function - but only if the sum of vFlocal > 0
      # (that means, only if indeed some terrestrial area is present
      # within the selected rings)

      if (sum(vFlocal) > 0) {


        ############################################
        # call optimization with the target function
        ############################################

        lResults <- RcppDE::DEoptim(tf, lower = rep(0, nTaxa), upper = rep(1, nTaxa),
                                          vPoldepRegio = vPoldepRegio, mKlocal = mKlocal,
                                          vFlocal = vFlocal, vSampleLocPro = vSampleLocRandPro,
                                          ppes = unlist(lParams$ppes$ppe),
                                          control = DEoptim.control(trace = FALSE, NP = 10 * nTaxa))


        ############################################
        # calculate the resulting pollen composition
        ############################################

        # extract the optimized local composition
        a <- lResults$optim$bestmem

        # transform into ratios
        a.pro <- a / sum(a)

        # calculate local pollen deposition
        mPoldepLocal <- t(t(mKlocal) * a.pro * unlist(lParams$ppes$ppe)) * vFlocal

        # sum up local and regional pollen deposition
        vPoldepTotal <- vPoldepRegio + colSums(mPoldepLocal)


        ############################################
        # write results
        ############################################

        # store pollen composition
        aPoldepTotalPro[,j,i] <- round(100 * vPoldepTotal /sum(vPoldepTotal),2)

        # store bestmen (best matching cover)
        aBestMem[,j,i] <- round(a.pro, 4)

        # store bestvalue
        mBestValue[j,i] <- lResults$optim$bestval


      } else {

        ############################################
        # write NAs when there is no terrestrial area in the local rings
        ############################################

        # store pollen composition
        aPoldepTotalPro[,j,i] <- NA

        # store bestmen (best matching cover)
        aBestMem[,j,i] <- NA

        # store bestvalue
        mBestValue[j,i] <- NA
      }
    }
  }

  mPoldepTotalProMean <- t(apply(aPoldepTotalPro, 1:2, mean))
  mPoldepTotalProQ10 <- t(apply(aPoldepTotalPro, 1:2, quantile, probs = 0.10, na.rm = TRUE))
  mPoldepTotalProQ90 <- t(apply(aPoldepTotalPro, 1:2, quantile, probs = 0.90, na.rm = TRUE))

  mBestMemMean <- t(apply(aBestMem, 1:2, mean))
  mBestMemQ10 <- t(apply(aBestMem, 1:2, quantile, probs = 0.10, na.rm = TRUE))
  mBestMemQ90 <- t(apply(aBestMem, 1:2, quantile, probs = 0.90, na.rm = TRUE))

  vBestValue <- rowMeans(mBestValue)

  return(list(cover = list(mean = mBestMemMean, Q10 = mBestMemQ10, Q90 = mBestMemQ90),
              pollenpercentages = list(mean = mPoldepTotalProMean, Q10 = mPoldepTotalProQ10, Q90 = mPoldepTotalProQ90),
              mBestValue = mBestValue))


}




#################################################################################
### target function
#################################################################################
# a <- runif(10)


tf <- function(a, vPoldepRegio, mKlocal, vFlocal, vSampleLocPro, ppes){

  # transform cover into ratios
  a.pro <- a / sum(a)

  # calculate local pollen deposition
  mPoldepLocal <- t(t(mKlocal) * a.pro * ppes) * vFlocal

  # sum up local and regional pollen deposition
  vPoldepTotal <- vPoldepRegio + colSums(mPoldepLocal)

  # calculate resulting pollen composition in the small basin
  vPoldepTotalPro <- vPoldepTotal /sum(vPoldepTotal)

  # add small value to avoid undefined log in vSampleLocPro
  return(logeuclidean(vPoldepTotalPro, vSampleLocPro + 0.001))
}



#################################################################################
### log-euclidean distance, performs better than simple euclidean distance
#################################################################################

logeuclidean <- function(a, b) sqrt(sum((log(a) - log(b))^2))




#################################################################################
### calculate dispersal & deposition factor K
#################################################################################

calK <- function(dfRadii, lParams){

  # TODO: to reduce calculations, k may just be calculated for unique falls speeds
  # vg <- sort(unique(lParams$fallspeed))

  # NOTE: the lake model in the disqover package needs a minimum basin diameter of 6 m
  # the maximum for regionCutoff is 100 km --> therefore the radius is checked before calculation

  # NOTE: calculations with the lake model are slow for large basins, as the effect is increasingly small
  # for large basins, calculations for larger rings are always done with the peatland model

  # FIXME: Lake model haut nicht richtig hin!

  # FIXME: for the time being, set basin type to 'peatland' - check lake model!
  #
  lParams$tBasin = "peatland"

  # prepare matrix for K-factors
  mK <- matrix(data = 0, nrow = length(dfRadii$no), ncol = length(lParams$fallspeed$fallspeed))
  rownames(mK) <- dfRadii$mean
  colnames(mK) <- lParams$fallspeed$Taxon

  # calculate k factor for each ring and fall speed
  for (i in 1:(length(dfRadii$no))){

    cat('\rRadius:', dfRadii$inner[i], '-',dfRadii$outer[i],'\t')
    if (dfRadii$outer[i] > 4000){
      lParams$tBasin = "peatland"
    }

    if ((lParams$tBasin == "lake") & (dfRadii$inner[i] < 6)){
      print('the lake model cannot be calculated for very small radii')
    } else {
      mK[i,] <- do.call(rbind,lapply(lParams$fallspeed$fallspeed, disqover::DispersalFactorK, tBasin = lParams$tBasin, dBasin = 2* dfRadii$inner[i], dwm = lParams$dwm, regionCutoff = dfRadii$outer[i]))


    }
  }
  return(mK)
}


