#' Example pollen data for LOVEr and LOVEoptim
#'
#' A data set containing local and regional pollen data for an example application
#' of LOVEr and LOVEoptim.
#'
#' @format A data frame with xy rows (=pollen taxa) and xy variables:
#'
#' @source simulated data
#'
#' Simulations were produced for publication of the LOVEr and LOVEoptim R functions
#' from the soil map BÜK300 and for the study site of Dobbin/north-eastern Germany
#'
#' EDIT: code
#'
"LOVEexamplePollen"
#'
#'
#'
#'
#'
#' Example parameters  for LOVEr and LOVEoptim
#'
#' A data set containing parameters for an example application
#' of LOVEr and LOVEoptim.
#'
#' @format A data frame with xy rows (=pollen taxa) and xy variables:
#' \describe{
#'  \item{ppes}{pollen productivity estimates and standard errors}
#'  \item{fallspeed}{fallspeed of pollen}
#'  \item{dBasinRegional}{diameter of the large lake}
#'  \item{dBasinLocal}{diameter of the small site}
#'  \item{tBasinRegional}{type of the large site (lake or peatland)}
#'  \item{tBasinLocal}{type of the small site (lake or peatland)}
#'  \item{dwm}{distance weighting method}
#'  \item{repeats}{number of repeated model runs (needed for error estimates)}
#'  \item{n}{number of EDIT: ?? }
#'  \item{error}{include/exclude noise in the calculations, logical vector}
#' }
#'
#' @source simulated data
#'
#' Simulations were produced for publication of the LOVEr and LOVEoptim R functions
#' from the soil map BÜK300 and for the study site of Dobbin/north-eastern Germany
#'
#' EDIT: code
#'
"LOVEexampleParams"
#'
#'
#'
#' Example ring data  for LOVEr and LOVEoptim
#'
#' A data set containing ring data for an example application
#' of LOVEr and LOVEoptim.
#'
#' @format A data frame with local and regional pollen counts for 10 pollen taxa
#' \describe{
#'  \item{no}{running number}
#'  \item{mean}{mean radius of each ring}
#'  \item{ring}{ring (=donut) area}
#'  \item{circle}{full circle area}
#'  \item{inner}{inner radius of each ring}
#'  \item{outer}{outer radius of each ring}
#'  \item{terrestrial}{cover of terrestrial vegetation in each ring}
#'  \item{peatland}{cover of peatlands in each ring}
#' }
#'
#' @source simulated data
#'
#' Simulations were produced for publication of the LOVEr and LOVEoptim R functions
#' from the soil map BÜK300 and for the study site of Dobbin/north-eastern Germany
#'
#' EDIT: code
#'
"LOVEexampleRings"

#'
#'
#'
#' Example data for application of the ervinr function
#'
#' A data set containing pollen data, land cover data and parameters
#' for an example application of the ervinr function (ERV submodel 4).
#'
#' @format A data frame with local and regional pollen counts for 10 pollen taxa
#' \describe{
#'  \item{pollen}{pollen data for 10 pollen taxa and from 30 sites}
#'  \item{lc}{landcover data for 10 pollen taxa and from 30 sites}
#'  \item{params}{parameters}
#' }
#'
#' @source simulated data
#'
#' Simulations were produced for publication of the ervinr R function as explained
#' in Theuerkauf, M., Couwenberg, J., 2022. Pollen productivity estimates
#' strongly depend on assumed pollen dispersal II: Extending the ERV model.
#' The Holocene 32, 1233–1250. https://doi.org/10.1177/09596836211041729
#'
#' EDIT: code
#'
"ERV_example_data"

#
# setwd("D:/Arbeit/DISQOVER/DISQOVER_0.9/disqover/data")
# LOVEexamplePollen <- as.data.frame(rbind(local = unlist(vSampleLoc[-1]),
#                    regional = unlist(vSampleReg[-1])))
#
# LOVEexampleParams <- params
# LOVEexampleRings <- dfRadii
#
# usethis::use_data(LOVEexamplePollen, LOVEexampleParams, LOVEexampleRings, overwrite = TRUE)
#
#
# setwd('D:/Arbeit/Kiel 2023/Experimente/Dobbin_forested_vector/')

