#include <Rcpp.h>
using namespace Rcpp;

// This is a simple example of exporting a C++ function to R. You can
// source this function into an R session using the Rcpp::sourceCpp
// function (or via the Source button on the editor toolbar). Learn
// more about Rcpp at:
//
//   http://www.rcpp.org/
//   http://adv-r.had.co.nz/Rcpp.html
//   http://gallery.rcpp.org/
//

//' calculate distance between true and modeled pollen for optimization
//' @param alpha random starting value, automatically provided
//' @export
// [[Rcpp::export]]

double distdefault(NumericVector alpha) {

  Environment e = Environment::global_env();
  Rcpp::NumericMatrix par = e["parf"];
  Rcpp::NumericMatrix pc = e["pcf"];
  Rcpp::NumericVector k = e["k"];
  Rcpp::NumericVector w = e["w"]; // taxa weights, if zero, taxon is removed
  double pot = e["pot"];
  String wopt = e["wopt"];
  int window = e["window"];
  int min = e["min"];

  int nrow = par.nrow(), ncol = par.ncol();
  int ncolt; // number of species with enough data for mean PoR values
  Rcpp::NumericMatrix por(nrow, ncol);
  Rcpp::NumericMatrix ri(nrow, ncol);
  Rcpp::NumericMatrix rii(nrow, ncol);
  Rcpp::NumericMatrix riii(nrow, ncol);


  Rcpp::NumericVector var = ncol;   // weighted variance
  Rcpp::NumericVector varw1 = ncol;  // weighted variance
  Rcpp::NumericVector varw2 = ncol;  // weighted variance
  Rcpp::NumericVector varw3 = ncol;  // weighted variance
  Rcpp::NumericVector varw4 = ncol;  // weighted variance
  Rcpp::NumericVector varw5 = ncol;  // weighted variance
  Rcpp::NumericVector sd = ncol;  // weighted variance
  Rcpp::NumericVector mcov = ncol; // mean cover of each species
  Rcpp::NumericVector csum = ncol; // mean counts of each species

  //
  NumericVector rollmean(NumericVector x, int window, int min);

  // ri - divide counts by PPE and K (= REVEALS step 1)
  Rcpp::NumericVector f = alpha * k;
  for (int i = 0; i < nrow; i++) {
    ri(i,_) = pc(i,_) / f;

  }


  // calculate proportions 'rii' (= REVEALS step 2)
  for (int i = 0; i < nrow; i++) {
    // first calculate row sums
    double s = 0;
    for (int j = 0; j < ncol; j++) {
      s += ri(i,j);
    }
    // now proportions
    rii(i,_) = 100 * ri(i,_) / s;
  }


  // calculate mean cover of each taxon 'mcov'
  // also add up counts for each taxon 'csum'
  for (int j = 0; j < ncol; j++) {
    double s = 0;
    for (int i = 0; i < nrow; i++) {
      s += rii(i,j);
      csum(j) += pc(i,j);
    }
    mcov(j) = s/nrow;
  }


  // calculate PoR ratio as pollen accumulation rate 'par' divided by cover 'rii'
  for (int i = 0; i < nrow; i++) {
    // double s = 0;
    for (int j = 0; j < ncol; j++) {
      // normal
      por(i,j) = par(i,j) / rii(i,j);
    }
  }

  // could be faster with Armadillo
  // por = armaMatDiv(par, rii)

  // calculate running mean
  NumericVector s, t;
  for (int j = 0; j < ncol; j++) {
    s = por(_,j);
    por(_,j) = rollmean(s, window, min);
  }

  ncolt = 0;

  // calculate variance in PoR ratio
  // loop over taxa
  for (int j = 0; j < ncol; j++) {
    double m = 0; // mean
    double s = 0; // mean
    double sos = 0; // sum of squares
    int nas = 0; // counter for NA values

    // first calculate row sums 's'
    for (int i = 0; i < nrow; i++) {

      // remove infinite values in the PoR ratio! (i.e. substitute with NaN)
      // see https://stackoverflow.com/questions/26241085/rcpp-function-check-if-missing-value
      if (Rcpp::traits::is_infinite<REALSXP>(por(i,j))) {
        por(i,j) = R_NaN;
      }

      // now sum up values (or count NA values - will be needed later)
      if (ISNAN(por(i,j))) {

        nas++;

      } else {
        s += por(i,j);
      }
    }


    // calculate row means of the PoR ratio 'm'
    m = s/(nrow-nas);


    // calculate squared distance from the mean 'riii'
    // riii(_,j) = (por(_,j) - m) * (por(_,j) - m);
    //riii(_,j) = abs(por(_,j) - m);
    riii(_,j) = abs(pow(abs(por(_,j) - m), pot));


    // sum up squared distances 'sos'
    for (int i = 0; i < nrow; i++){
      if (!ISNAN(por(i,j))) {
        sos += riii(i,j);
      }
    }


    // initialize variables
    // three type - unweighted variance (var), weighted by mean (varw1) and sqrt weighted by mean (varw2)
    var(j) = 0;
    varw1(j) = 0;
    varw2(j) = 0;
    varw3(j) = 0;
    varw4(j) = 0;
    varw5(j) = 0;
    sd(j) = 0;


    // calculate mean variance, but check that at least one value exists
    if (nrow - 1 - nas > 0){

      // count this taxon
      ncolt += 1;

      // calculate variance
      var(j) = sos/ (nrow - 1 - nas);

      // weight variance by mean PoR
      varw1(j) =  var(j) / m;

      // weight sqrt of variance by mean PoR
      varw2(j) = sqrt(var(j)) / m;

      // weight sqrt of variance by mean PoR
      varw3(j) = (var(j)) / sqrt(m);

      // weight sqrt of variance by mean PoR
      varw4(j) = sqrt(var(j)) / sqrt(m);

      // weight sqrt of variance by mean PoR
      varw5(j) = var(j) / (m * m);

      sd(j) = sqrt(sos / (nrow - 1 - nas));
    }

  }


  double ret;
  if (wopt == "varsum") ret = sum(var); // sum of variance, for each taxon weighted by mean
  else if (wopt == "varsumw1") ret =  sum(varw1);
  else if (wopt == "varsumw2") ret =  sum(varw2);
  else if (wopt == "varsumw3") ret =  sum(varw3);
  else if (wopt == "varsumw4") ret =  sum(varw4);
  else if (wopt == "varsumw5") ret =  sum(varw5);
  else if (wopt == "sd") ret =  sum(sd);


  return ret;
}

