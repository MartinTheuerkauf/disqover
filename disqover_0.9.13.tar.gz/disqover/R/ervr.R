#' ERV submodel 4
#'
#' Calculate pollen productivity estimate from surface pollen + vegetation data
#' using ERV submodel 4.
#'
#' EDIT how about basin sizes? set automatically using the GIS data?
#'
#'
#' @param pollen - pollen counts with taxa in columns and sites in rows
#' @param lc - land cover data, a list of data frames (one for each site)
#' with land cover composition at each site, the first two columns (ri and ro)
#' include the inner and out radius of each ring (donuts!), the following
#' columns give the cover of each plant taxon in m² (the order of taxa
#' must be the same as for the pollen data).
#' @param params - a list of parameters
#' params$vg - fall speed of pollen of each pollen taxon
#' params$tBasin - type of the basin, either 'lake' or 'peatland'
#' params$regionCutoff - largest distance include in the pollen dispersal
#' calculations, by default set to 100 km (1e5 m)
#' params$dwm -   the distance weighting method, by default set to
#' 'lsm unstable', other options are 'gpm neutral', 'gpm unstable' (see the
#' distance weighting function for further detailes)
#' params$error - Boolean, if TRUE, errors are added in the pollen
#' counts during each model run, error calculation is described in Theuerkauf &
#' Couwenberg et al. 2022
#' params$perror - Boolean, if TRUE, errors are added in the pollen
#' productivity estimates during each model run, error calculation is described
#' in Theuerkauf & Couwenberg et al. 2022
#'
#'
#' @return ervinr returns a list of 5 data frames with results and data for evaluation.
#' @return ...bestval:	Value to be optimized in the objective function
#' (= squared-chord-distance between observed and modeled pollen  percentage  values)
#' @return ...alpha: Pollen productivity estimates, depending on the method, rescaling
#' to the reference taxon may be necessary
#' @return ...cover: Modeled, proportional regional cover values of each taxon,
#' calculated for increasing ring sizes.
#' @return ...mp: Modeled pollen proportions for each pollen taxon at each site and
#' for each selected distance for evaluation of the results. MP is a list of data frames,
#' with each data frame including the results for each pollen taxon and site.
#' @return ...dwpaloc: Distance weighted local plant abundances of each pollen taxon
#' at each site and for each ring. dwpaloc is a list of data frames, with each
#' data frame reflecting distance weighted plant abundances at one site, with
#' pollen taxa in columns and rings in rows. May be Useful for evaluation
#' of the results.
#'
#' @author Martin Theuerkauf <martin.theuerkauf@greifswaldmoor.de>
#' @references Theuerkauf, M., Couwenberg, J., 2022. Pollen productivity
#' estimates strongly depend on assumed pollen dispersal II:
#' Extending the ERV model. The Holocene 32, 1233–1250.
#' https://doi.org/10.1177/09596836211041729
#'
#' @examples \dontrun{
#' ## Example application with simulated data from Theuerkauf & Couwenberg (2022).
#'
#' # load example data
#' l_erv_example <- disqover::ERV_example_data
#' pollen <- l_erv_example$pollen
#' lc <- l_erv_example$lc
#' params <- l_erv_example$params
#'
#' ## apply ERV submodel 4
#' df_results <- ervinr(pollen = pollen, lc, params)
#' }
#'
#' @import plyr
#' @export


##################################################
#### ERV model 4 - the wrapper function
###################################################


ervinr <- function(pollen, lc, params){

  # lowercase for better handling...
  params$dwm <- tolower(params$dwm); params$tBasin <- tolower(params$tBasin)

  # if not already done, convert pollen data to data frame
  pollen <- as.data.frame(pollen)

  # check parameters
  if (!check.ERV.input(pollen, lc, params)){
    stop ("Some parameter is not suitable - check and correct")
  }

  # get dimensions
  nTaxa <- ncol(pollen)
  nSites <- length(lc)


  #### preparing the local part
  # get radii
  r <- as.data.frame(lc[[1]][,1:2])

  # get weighting factors for local rings
  wfloc <- as.data.frame(dwf.f(r, params))

  # pollen percentage (add error??)
  pollenPer <- prop.table(as.matrix(pollen), 1)

  # add error in pollen data if wanted
  if (params$error){
    #pollenPer2 <- t(apply(pollen, 1, function(x) rmultinom_reveals(pollen=x)))
    pollen2 <- t(apply(pollen, 1, function(x) rmultinom(1, sum(x), x/sum(x))))
    colnames(pollen2) <- colnames(pollenPer)
    pollenPer <- prop.table(pollen2, 1)
  }

  # calculate distance weighted abundances
  # first remove radii
  lc2 <- lapply(lc, function(x) x[,-c(1:2)])

  # multiply with weighting factor and divide by total ring cover (rowSums)
  dwpaloc <- lapply(lc2, function(x) x*wfloc/rowSums(x))

  # iteratively sum up
  ox <- list()
  wfreg <- list()
  mp <- list() # modelled pollen

  # for testing: i <- 18
  for (i in 2:(nrow(r)-1)){

    print(i)
    # calculate distance weighted, local abundance (dl)
    # for each respective distance the dwpa in all rings within that distance is summed up

    if (i == 1) {     # EDIT: for loop starts with i = 2!
      dl <- ldply(dwpaloc, function(x) x[1,])
    } else {
      dl <- ldply(dwpaloc, function(x) colSums(x[1:i,], na.rm = TRUE))
    }

    # in case ldply delivers an extra column
    if (ncol(dl) > nTaxa) dl <- dl[,-1]

    # calculate radii for region
    # that ranges from the present radius to regioncutoff
    rreg <- cbind(r[i,2], params$regionCutoff)

    # calculate distance weighting factors for regional component
    wfreg[[i]] <- dwf.f(rreg, params)

    # multiply for each site
    kr <- matrix(rep(wfreg[[i]], nSites), ncol = nTaxa, byrow=TRUE)

    # start optimization

    # set margins for optimization for both pollen productivity (0.01 to 20)
    # and regional cover (0 to 10)
    # EDIT: not applicable with current optimzer
    # lower <- c(params$ppelow, rep(0, nTaxa))
    # upper <- c(params$ppeup, rep(10, nTaxa))

    # set random starting values
    par <- runif(n=2 * nTaxa, min = 0.01, max = 20)

    # call optimizer
    # EDIT: params$strategy may be included as parameter
    # EDIT: check ERVinR model 4 v.0.6.R for alternative optimizing options
    # EDIT: lower/upper not used in this version?!
    ox[[i]] <- optim(par=par, fn=optimERV, method = "CG", control=list(maxit=3000), dl=dl, kr=kr, pollenPer=pollenPer, strategy = 'fix')


    # call again optimizing function to retrieve modeled pollen percentages
    ox[[i]]$par <- abs(ox[[i]]$par) # remove negative values
    x <- ox[[i]]$par  # extract optimized values

    mp[[i]] <- optimERV(par=x, pollenPer=pollenPer, dl=dl, kr=kr, strategy = 'fix', justpollen=TRUE)
  } # end of loop over radii



  ### Data extraction ERV

  # extract alphas (=pollen productivity) and cr (regional cover)
  x <- ldply(ox, function(x) x$par)  # extract optimized values

  if (ncol(x) > 2 * nTaxa) x <- x[,-1] # in case there is a header column
  alpha <- x[,1:nTaxa]
  cr <- x[,(nTaxa + 1):(2 * nTaxa) ] # cover regional

  # regional cover
  crm <- 100 * prop.table(abs(as.matrix(cr)),1) # rescale regional cover to a sum of 100 %

  # wfr <- ldply(wfreg, function(x) x)
  #
  # # multiply cover and weighting factor to calculate distance weighted regional cover
  # dwpareg <- crm*as.matrix(wfr)
  #
  #
  # # sum up dwpa local (to transform dwpa in single rings to full circles)
  # # start with first row
  # dl <- lapply(dwpaloc, function(x) x[1,])
  #
  # for (i in 2:nrow(r)){
  #   dl2 <- (lapply(dwpaloc, function(x) colSums(x[1:i,], na.rm=TRUE)))
  #   #dl <- lapply()
  #   for (j in 1:nSites) dl[[j]]<- rbind(dl[[j]], dl2[[j]])
  # }
  #
  # # jetzt noch regional addieren und mit alpha multiplizieren
  # pd <- list()
  # for (j in 1:nSites) pd[[j]]<- (dl[[j]]+dwpareg) * alpha
  #
  # dl[[1]]
  # dwpareg
  #
  # # and calculate percentages
  # pp <- list()
  # for (j in 1:nSites) pp[[j]]<- prop.table(as.matrix(pd[[j]]), 1)
  #
  # # and select pollen deposition calculated with all local rings
  # modpol <- pp[[1]][nrow(pp[[1]]),]
  # for (j in 2:nSites) modpol <- rbind(modpol, pp[[j]][nrow(pp[[j]]),])
  #

  # extract bestval (minimum value to be optimized)
  bestval <- ldply(ox, function(x) x$value)

  if (ncol(bestval) > 2*nTaxa) bestval <- bestval[,-1]

  # add col/row names
  r_mean <- apply(r, 1, mean)[2:(nrow(r)-1)] # mean ring radii

  # bestval - minimum value to be optimized
  rownames(bestval) <- r_mean
  colnames(bestval) <- 'bestval'

  # alpha - pollen productivity estimates (raw values)
  rownames(alpha) <- r_mean
  colnames(alpha) <- colnames(pollen)

  # crm - modeled regional cover
  rownames(crm) <- r_mean
  colnames(crm) <- colnames(pollen)

  # mp - modeled pollen values
  for (i in 2:length(mp)){
    colnames(mp[[i]]) <- colnames(pollen)
  }

  # dwpa - dwpa abundances in local rings
  for (i in 1:length(dwpaloc)){
    colnames(dwpaloc[[i]]) <- colnames(pollen)
  }

  return(list(bestval=bestval, alpha=alpha, cover=crm, mp = mp, dwpaloc=dwpaloc))
}



################################################################################
#### objective function - calculates the value to be optimized
################################################################################

optimERV = function(par, pollenPer, dl, kr, strategy, justpollen=FALSE){

  par <- abs(par) # to not run into negative values

  # extract random values for productivity (here not named ppe but alpha to avoid confusion) and regional cover (cr)
  alpha <- par[1:(length(par)/2)]

  cr <- par[(length(par)/2 + 1):length(par)]

  if (strategy == "fix") cr <- cr / sum(cr)

  # locdwpa muss mit alpha multipliziert werden
  # K mit Deckung und alpha

  # local pollen deposition (pl)
  pl <- t(t(dl) * alpha)

  # regional pollen deposition (pr)
  pr <- t(t(kr)  * alpha * cr)

  # ein Versuch..
  # totalpar <- matrix(mapply(`+`, pl, pr), ncol=length(alpha))

  # sum up local and regional deposition --> pollen proportions
  pt <- prop.table(pl+pr, 1)


  # if 'justpollen' is TRUE --> just return pollen proportions
  if(justpollen){
    cs <- pt
  } else {

    # otherwise return square root distance between true and modeled pollen values
    # Var. 1
    rms <- sqrt((pollenPer-pt)^2)
    cs <- sum(colSums(rms, na.rm = TRUE))

    # EDIT: alternative distances for checking
    # Var. 2
    # dis <- t(t((pt-pollenPer)^2)/alpha)

    # Var.3 calculate sum of squares and sum up
    # dis <- t(t(sqrt((pollenPer-pt)^2))/alpha)
    # cs <- (colSums(rms, na.rm = TRUE))

    # b <- c(0.1, 1,5,10)
    # b^0.25

    # Var. 4 distance 2: top in EDA, aber hier nicht so erfolgreich:
    # dis <- ((pt-pollenPer)^2)/((pollenPer+1)*alpha)

  }
  return(cs)
}




###################################################
#### Calculate distance weighting factors
###################################################

# EDIT: Why variable lcs?
dwf.f <- function(lcs, params){

  # extract radii
  rin <- c(lcs[,1])
  rout <- c(lcs[,2])

  # K Factor inner rings
  kin <- ldply(params$vg, function(x) disqover::DispersalFactorK(x, tBasin = params$tBasin, dBasin = 2*rin, dwm = params$dwm, regionCutoff = params$regionCutoff))

  # K Factor outer rings
  kout <- ldply(params$vg, function(x) disqover::DispersalFactorK(x, tBasin = params$tBasin, dBasin = 2*rout, dwm = params$dwm, regionCutoff = params$regionCutoff))

  # return distance weighting factors
  return(t(kin[-1]-kout[-1]))
}



################################################################################
#### check input values to identify missing or wrongly formatted input
#### EDIT needs checking (e.g. checking taxon names)
################################################################################


check.ERV.input <- function(pollen,  lc, params){

  # EDIT: test whether all pollen taxa are in the parameter list (their order is not important)
  # if(!all(colnames(pollen[,-1]) %in% rownames(params), na.rm = FALSE))
  #   stop("STOP: Not all pollen taxa found in the parameter list")

  # check distance weighting method
  if (!isTRUE((params$dwm=="lsm unstable") | (params$dwm=="gpm neutral") | (params$dwm=="gpm unstable") | (params$dwm=="1overd")))
    stop("distance weighting method not defined; should be 'LSM unstable', 'GPM neutral', 'GPM unstable' or '1overd' ")

  # check basin type
  if (!isTRUE((params$tBasin=="peatland") | (params$tBasin=="lake")))
    stop("basin type ('tBasin') not defined; should be 'peatland' or 'lake'")

  # EDIT: check basin diameter (not necessary here?)
  # if (!isTRUE(dBasin == floor(dBasin))) stop("basin size ('dBasin') should be an integer value")
  # if (dBasin < 10) stop("basin diameter ('dBasin') should be at least 10 m")

  # EDIT: check number if iterations (should be >= 1000) (not necessary here?)
  # if (!isTRUE(n == floor(n))) stop("'n' should be an integer value")
  # if(verbose){
  #   if (n < 1000) message("Warning: for sensible error estimates, 'n' should be at least 1000")
  # }

  # check vg values, should be between 0.01 and 0.15
  if(max(params$vg)>0.15) stop ("fallspeed(s) too high (>0.15 m/s), please check")
  if(min(params$vg)<0.01) stop ("fallspeed(s) too low (<0.01 m/s), please check")

  # EDIT ppe column present?
  # if(!'ppe' %in% tolower(names(params)))
  #   stop("STOP: no 'ppe' column in the parameters ")

  # EDIT PPE.errors column present?
  # if(!'ppe.error' %in% tolower(names(params)))
  #   stop("STOP: no 'ppe.error' column in the parameters ")

  return(TRUE)
}


##################################################
#### optimPPE
###################################################

# EDIT -needed here??
optimPPE <- function(par, pollenPer, dl){

  #pollenPer, dl, kr, strategy
  #par <- abs(par) # to avaid running into negative values

  # extract random values for productivity (here not named ppe but alpha to avoid confusion)
  alpha <- par
  #alpha[reftax] <- 1 # set reference to 0

  # locdwpa muss mit alpha multipliziert werden
  # K mit Deckung und alpha

  # local pollen deposition (pl)  (geht das charmanter??)
  pl <- t(t(dl) * alpha)

  # pollen proportions
  pt <- prop.table(pl, 1)

  # Var. 2
  dis <- sqrt((pt-pollenPer)^2)
  #dis <- ((pt-pollenPer)^2)/(alpha)

  return(sum(dis))
}

