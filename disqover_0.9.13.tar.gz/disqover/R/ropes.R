#' ROPES
#'
#'
#' @description Apply ROPES approach. \pkg{\link{Rmalschains}} package required.
#'
#' The ROPES approach (Reveals withOut PpES; Theuerkauf and Couwenberg 2018;
#' doi: 10.3389/feart.2018.00014) aims to translate pollen data from large
#' sites into regional vegetation composition. ROPES builds on the REVEALS model
#' (Sugita 2007). However, other than REVEALS, the ROPES approach allows
#' reconstruction without given pollen productivity estimates (known as PPEs or
#' RPPES). To that end, ROPES additionally employs pollen accumulation rates
#' (PAR). PARs provide independ information about the changes in abundance
#' for each species. ROPES uses this additional information, i.e. it fits a
#' REVEALS reconstruction to the changes known from the PAR data. So, all
#' changes shown in the PAR data should be similarly present in a REVEALS
#' reconstruction. ROPES applies optimization to find the set of PPEs that
#' produces the best matching reconstruction. To that end, ROPES minmizes
#' variation in the ratio of PAR values over abundance reconstructed with
#' REVEALS (PoR ratio).
#'
#' ROPES requires both pollen counts and PAR value from a pollen records For
#' successful application, pollen records with sufficient variation in most
#' pollen taxa along the record. Furthermore, successful application is
#' determined by the quality of the PAR value.
#'
#' The ROPESinR function returns a list with betval (the value to be reached in
#' optimization), iter (the number of iterations needed), the resulting PPEs,
#' the resulting cover of each taxon, the initial PAR values and the PoR ratio.
#'
#'
#'

# both version have 3 weighting options
# 1. divide each colum (PoR or variance) by the mean --> similar weight for each taxon
# 2. divide each colum (PoR or variance) by the sqrt of mean --> less weight to rarer taxa
# 3. divide each colum (PoR or variance) by the log of mean --> less weight to rarer taxa
# How does it all work?? - besser beschreiben!!
# wo werden Parameter über weighting method übergeben!

#' @param pc a matrix with raw pollen counts. Counts are arranged as pollen
#'   taxa in columns and samples in rows. The first colum includes sample ages
#'   or depth, i.e. only numeric values! The first row includes taxon names.
#' @param par a matrix with pollen accumulation rates. Values are arranged
#'   like the pollen counts, i.e. as pollen taxa in columns and samples in rows.
#'   pc and par must have the same dimensions. The first colum includes sample
#'   ages or depth, i.e. only numeric values! The first row includes taxon
#'   names.
#' @param p data frame of parameters. Includes 'fallspeed' of pollen (in m
#'  s-1), relative pollen productivity estimates ('PPE') and their standard
#'  error. Pollen taxa are given in rows, parameters in colums.  Column names
#'  must be "species", "fallspeed", "ppe", and "ppe.error". See 'paramsTS' in
#'  the 'Tiefer See' data set as example. For each pollen taxon in the pollen
#'  data, one record of parameters with exactly the same name is required.
#'  Params may include more taxa, also in different order, so that a standard
#'  list may be established. !!!!!!!!!!!!! now also ppe-limits !!!!!!!!!
#' @param otype select optimization method, either "malschains"
#' (from Rmalschains package), "GenSA" (from GenSA package) or
#' "DEoptim" (from RcppDE package).
#' @param rtype select a strategy ("single" or "mean") to calculate overall
#'  variation in the PoR ratio. With "single", first variance in the PoR ratio
#'  of each taxon is calculated and then summed up to overall variance.
#'  With "mean", first a mean PoR ratio of all taxa and then variation of
#'  this mean PoR is calculated. Use tests to explore which strategy performs
#'  best with your record.
#' @param wopt select taxa weighting for calculation of mean variance
#' (with strategy "single") or mean PoR (with strategy mean).
#' Available options are "mean", "log.mean" or "sqrt.mean".
#' Use tests to explore which strategy performs best with your record.
#' @param parError if TRUE, noise is added in PAR data in each model run.
#'   Magnutide of error is defined by parErrorValue. This option may be useful
#'   in simulation studies. By default FALSE.
#' @param pcError if TRUE, noise is added in pollen counts through re-drawing.
#'   Magnitude of noise is defined by pollen sum, here set to 1000 (may be
#'   changed in the code). This option may be useful in simulation studies. By
#'   default FALSE.
#' @param parErrorValue defines the magnitude of noise added in PAR data. To add
#'   noise, each PAR value is multiplied by a random value from a normal
#'   distribution, divided by parErrorValue and than added to the original PAR
#'   values. So higher parErrorValues produce lower noise.
#' @param dBasin basin diameter in meter
#' @param dwm distance weighting method. The following methods are implemented:
#'   'lsm unstable', 'gpm unstable', 'gpm neutral'. 'lsm' refers to the the
#'   Lagrangian stochastic model presented by Kuparinen et al. 2007 (Ecological
#'   Modelling 208:177-188 ). 'gpm' refers to the Gaussian plume model, based on
#'   Sutton's equations, used by Prentice 1985 (Quaternary Research 23: 76-86).
#'   Further methods can be added.
#' @param tBasin type of basin, either 'lake' or 'peatland'
#' @param regionCutoff diameter of the reconstruction region in meters, by
#'   defaults to 1e5 m
#' @param itermax control parameter of DEoptim, setting the maximum number of
#'   iterations. By default 20000.
#' @param maxEvals control parameter of DEoptim.
#' @param pot ...
#' @param window ...
#' @param min ...
#'
#'
#' @author Martin Theuerkauf <martin.theuerkauf@uni-greifswald.de>
#' @import Rmalschains
#' @import GenSA
#' @import RcppDE
#' @import stats
#' @export
#'
# Intro mal durchgehen
# anpassen: species names trimmen, damit das keine Fehler gibt

# new in version 0.4
# added: 2 types (mean and single PoR) with 3 options (mean, sqrt.mean, log.mean)

# news in Version 0.3
# optimzing function in rcpp - und damit viel schneller
# GenSA as new optimzer
# alle parameter in ein File (also PPEs, fallspeed and ranges)


# news in Version 0.2.1
# 1. first colum in pc and par will be removed in the code, so both now must contain age/depth data
# 2. alternative optimizer added

###########################################################
###  the ROPES main function
###########################################################



# bei lo und up sind Werte nahe 100 noch nicht sauber erfasst (halbe Spannen gibt es noch nicht)??
ROPESinR <- function (pc, par, p, itermax = 10000, pcError = FALSE, parError = FALSE, parErrorValue, dBasin, otype = "malschains", rtype = "single", wopt = "sqrt.mean", dwm="lsm unstable", tBasin="lake", regionCutoff=1e5, maxEvals = 1e5, pot = 1.1, window = 5, min = 3){


  ############################################################################
  ### check input
  ############################################################################
  message("richtig!")

  # lowercase for better handling...
  dwm <- tolower(dwm)
  tBasin <- tolower(tBasin)
  names(p) <- tolower(names(p))
  otype <- tolower(otype)
  rtype <- tolower(rtype)
  wopt <- tolower(wopt)

  # optimization method
  if (tolower(otype) == "deoptim"){
    message("Optimization with DEoptim selected!")
  } else if (tolower(otype) == "gensa"){
    message("Optimization with GenSA selected!")
  } else if (tolower(otype) == "malschains"){
    # message("Optimization with Malschains selected!")
  } else {
    stop("no valid optimization method selected (Malschaeins, GenSA or DEoptim)")
  }

  # basin size
  if ((dBasin/2) > regionCutoff) stop("Stop: Basin larger than the size of the region (regionCutoff) - that does'nt work!")

  # test whether all pollen taxa are in the parameter list (their order is not important)
  # the column name should be taxon rather than species
  # also - it should check whether the column is missing (column named "taxon" missing) or whether indeed taxa are missing!

  # trim taxon names before comparison
  p$species <- trimws(p$species)
  colnames(pc[,-1]) <- trimws(colnames(pc[,-1]))

  if(!all(colnames(pc[,-1]) %in% p$species, na.rm = FALSE))
    stop("STOP: Not all pollen taxa found in the parameter list")


  # check that pc and par are similar in structure!

  # check distance weighting method
  if (!isTRUE((dwm=="lsm unstable") | (dwm=="gpm neutral") | (dwm=="gpm unstable") | (dwm=="1overd")))
    stop("distance weighting method not defined; should be 'LSM unstable', 'GPM neutral', 'GPM unstable' or '1oved' ")

  # check basin type
  if (!isTRUE((tBasin=="peatland") | (tBasin=="lake")))
    stop("basin type ('tBasin') not defined; should be 'peatland' or 'lake'")


  # check weights: 0 < weight < 1
  # what else ?
  # guck mal bei REVEALS und so...

  # check names in p (ppe, lower, upper)

  ############################################################################
  ### prepare parameters
  ############################################################################

  # read fall speed (vg) and ppes, unlist scheint nicht elegant ist aber n?tig
  # kann auch flexibler werden
  vg <- unlist(p[,2])

  # remove age/depth colum
  pc <- pc[,-1]
  par <- par[,-1]


  # calculate K factors (parameters should provided by users)
  # muss noch in Parameters eingebaut werden
  k <- do.call(rbind,lapply(vg, disqover::DispersalFactorK, tBasin=tBasin, dBasin=dBasin, dwm=dwm,
                            regionCutoff=regionCutoff))

  # wird das überhaupt gebraucht?
  nTaxa <- nrow(p)
  nSamples <- nrow(par)

  lo <- as.numeric(p$lower) # set PPE limits
  up <- as.numeric(p$upper) # set PPE limits

  # weights to handle rare/problematic taxa
  # prüfen ob Spalte existiert, wenn nicht mit 1 füllen
  w <- p$weights

  # par <- runif(length(lo),0.3,15) not needed...

  # for tests - add PAR error
  if (parError) {
    noise <- rnorm(nSamples)/parErrorValue # damit es nicht zu gross wird, Faktor variabel
    par <- par + par*noise
  }

  # if (pcError) {
  #   # nicht fertig - ergänzen! auf Basis der PARs berechnen?? eigentlich nicht nötig, die percenages ändern sich ja nicht durch noise in the PARs
  #   # noise <- rnorm(nSamples)/parErrorValue # damit es nicht zu gross wird, Faktor variabel
  #   # par <- par + par*noise
  # }

  # make sure all necessary values are in the global environment
  assign("k", as.vector(k), envir = .GlobalEnv)
  assign("w", as.vector(w), envir = .GlobalEnv)
  assign("wopt", wopt, envir = .GlobalEnv)
  assign("window", window, envir = .GlobalEnv)
  assign("min", min, envir = .GlobalEnv)
  assign("pot", as.double(pot), envir = .GlobalEnv)
  assign("pcf", as.matrix(pc), envir = .GlobalEnv)
  assign("parf", as.matrix(par), envir = .GlobalEnv)



  #################################
  # Rccp version of DEoptim
  #################################

  if (otype == "deoptim"){

      if (rtype == "single") {
        ropes <- RcppDE::DEoptim(distSingle, lower = lo, upper = up,
                RcppDE::DEoptim.control(itermax = itermax, NP=nTaxa*10))

      } else {
        ropes <- RcppDE::DEoptim(distMean, lower = lo, upper = up,
                RcppDE::DEoptim.control(itermax = itermax, NP=nTaxa*10))
      }

    # extract  data...
    bestval <- ropes$optim$bestval
    it <- ropes$optim$iter
    alpha <- ropes$optim$bestmem
  }



  #################################
  # GenSA optimization  - scheint nicht mit C++ objectiv functions zu arbeiten
  #################################

  if (otype == "gensa"){

    # message("Optimization with GenSA selected!")

    global.min <- 0
    tol <- 1e-13 #-13 ...

    if (rtype == "single") {
      ropes <- GenSA::GenSA(lower = lo, upper = up, fn = distSingle,
                   control=list(threshold.stop=global.min+tol,verbose=TRUE))
    } else {
      ropes <- GenSA::GenSA(lower = lo, upper = up, fn = distMean,
                     control=list(threshold.stop=global.min+tol,verbose=TRUE))
    }
    # extract bestvalue, number of iterations and resulting PPEs
    bestval <- ropes$value
    it <- ropes$counts
    alpha <- ropes$par
  }



  #################################
  # Rmalschains
  #################################

  if (otype == "malschains"){

    # message("Optimization with malschains selected!")
    # if no other option specified --> default will be applied

    if (rtype == "mean") {ropes <- Rmalschains::malschains(fn=distmean, lower=lo, upper=up, maxEvals=maxEvals, verbosity = 0, window = 5, min = 3, control=malschains.control(popsize=10*nTaxa, istep=300, optimum=0, ls="cmaes"))

    } else if (rtype == "runmean") {
      print("runmean selected")
      ropes <- Rmalschains::malschains(fn=dist_rollmean, lower=lo, upper=up, maxEvals=100000, verbosity = 0, control=malschains.control(popsize=10*nTaxa, istep=300, optimum=0, ls="cmaes"))

    } else if (rtype == "sqrt") {
      ropes <- Rmalschains::malschains(fn=distsqrt, lower=lo, upper=up, maxEvals=100000, verbosity = 0, control=malschains.control(popsize=10*nTaxa, istep=300, optimum=0, ls="cmaes"))

    # now the default...
    } else {ropes <- Rmalschains::malschains(fn=distdefault, lower=lo, upper=up, maxEvals=maxEvals, verbosity = 0, control=malschains.control(popsize=10*nTaxa, istep=300, optimum=0, ls="cmaes"))}

    bestval <- ropes$fitness
    it <- ropes$numTotalEA
    alpha <- ropes$sol
  }

  #################################
  # calculate further results
  #################################

  f <- as.vector(k*alpha)
  RI <- t(t(pc) / f) # Reveals step I
  RII <- 100*prop.table(RI, 1) # Reveals step II

  # calculate range of maxCover
  por <- par/RII


  return(invisible(list(bestval = bestval, iter = it, PPEs = alpha, cover = RII, PoRratio = por)))

}



###########################################################
###  testing the dist function
###########################################################


testDistFunction <- function(){


  library(disqover)
  # library(RcppRoll)

  setwd("D:/Arbeit/DISQOVER/ROPES/EuroTransect/sites/Tiefer See/test July 2023")

  p <- readODS::read_ods(path = "test_data.ods", sheet = "params")
  k <- unlist(readODS::read_ods(path = "test_data.ods", sheet = "k"))
  pc <- readODS::read_ods(path = "test_data.ods", sheet = "pc")
  par <- readODS::read_ods(path = "test_data.ods", sheet = "par")

  pot <- 1.05
  rtype <- 'default'
  wopt <- "varsumw1"
  window <- 5
  min <- 3

  dwm <- "lsm unstable"  # distance weighting option
  dBasin <- 600
  tBasin <- "lake"    # type of basin (could also be "peatland")
  regionCutoff <- 1e5  # region cutoff

  names(p) <- tolower(names(p))

  ############################################################################
  ### prepare parameters
  ############################################################################

  vg <- unlist(p[,2])
  # pc <- pc[,-1]
  # par <- par[,-1]

  # wird das überhaupt gebraucht?
  nTaxa <- nrow(p)
  nSamples <- nrow(par)

  # make sure all necessary values are in the global environment
  assign("k", as.vector(k), envir = .GlobalEnv)
  # assign("w", as.vector(w), envir = .GlobalEnv)
  assign("wopt", wopt, envir = .GlobalEnv)
  assign("window", window, envir = .GlobalEnv)
  assign("min", min, envir = .GlobalEnv)
  assign("pot", as.double(pot), envir = .GlobalEnv)
  assign("pcf", as.matrix(pc), envir = .GlobalEnv)
  assign("parf", as.matrix(par), envir = .GlobalEnv)


  # write data files for manual checking
  # write_ods(pc, "test_data.ods", sheet = "pc")
  # write_ods(as.data.frame(parf), "test_data.ods", sheet = "par", append = TRUE)
  # write_ods(as.data.frame(k), "test_data.ods", sheet = "k", append = TRUE)
  # write_ods(as.data.frame(p$ppe), "test_data.ods", sheet = "ppe", append = TRUE)

  res <- disqover:::dist_rollmean(p$ppe)
  # roll_mean(res[,3],5, na.rm = TRUE, align = 'left')
}

