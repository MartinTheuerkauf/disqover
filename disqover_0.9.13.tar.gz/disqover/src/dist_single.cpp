#include <Rcpp.h>
using namespace Rcpp;

// Experiment to minimize variation along records through  running mean
// schon mal probiert in 2021, im Juli 2023 nochmal aufgegriffen
//
// Idee: PoR normal berechnen, dann runmean (mit variabler Länge), dann sd berechnen
//
// old: to this end PoR ratio is first rescaled (divide by sd) to mean = 0 und sd = 1
// old: has not show successful in some tests

// This is a simple example of exporting a C++ function to R. You can
// source this function into an R session using the Rcpp::sourceCpp
// function (or via the Source button on the editor toolbar). Learn
// more about Rcpp at:
//
//   http://www.rcpp.org/
//   http://adv-r.had.co.nz/Rcpp.html
//   http://gallery.rcpp.org/
//

//' calculate distance between true and modelled pollen for optimization
//' @param alpha random starting value, automically provided
//' @export
// [[Rcpp::export]]

double distSingle(NumericVector alpha) {

  Environment e = Environment::global_env();
  Rcpp::NumericMatrix par = e["parf"];
  Rcpp::NumericMatrix pc = e["pcf"];
  Rcpp::NumericVector k = e["k"];
  Rcpp::NumericVector w = e["w"]; // taxa weights, if zero, taxon is removed
  String wopt = e["wopt"];

  int nrow = par.nrow(), ncol = par.ncol();
  int ncolt; // number of species with enough data for mean PoR values
  Rcpp::NumericMatrix por(nrow, ncol);
  Rcpp::NumericMatrix ri(nrow, ncol);
  Rcpp::NumericMatrix rii(nrow, ncol);
  Rcpp::NumericMatrix riii(nrow, ncol);
  Rcpp::NumericMatrix riiii(nrow, ncol);
  Rcpp::NumericMatrix pornorm(nrow, ncol);
  Rcpp::NumericVector vm = nrow;
  Rcpp::NumericVector var = ncol;
  Rcpp::NumericVector vec = nrow;
  Rcpp::NumericVector mcov = ncol; // mean cover of each species
  Rcpp::NumericVector csum = ncol; // mean counts of each species


  // ri - divide counts by PPE and K (= REVEALS step 1)
  Rcpp::NumericVector f = alpha * k;
  for (int i = 0; i < nrow; i++) {
    ri(i,_) = pc(i,_) / f;

  }


  // calculate proportions 'rii' (= REVEALS step 2)
  for (int i = 0; i < nrow; i++) {
    // first calculate row sums
    double s = 0;
    for (int j = 0; j < ncol; j++) {
      s += ri(i,j);
    }
    // now proportions
    rii(i,_) = 100 * ri(i,_) / s;
  }


  // calculate mean cover of each taxon 'mcov'
  // also add up counts for each taxon 'csum'
  for (int j = 0; j < ncol; j++) {
    double s = 0;
    for (int i = 0; i < nrow; i++) {
      s += rii(i,j);
      csum(j) += pc(i,j);
    }
    mcov(j) = s/nrow;
  }


  // calculate PoR ratio as pollen accumulation rate 'par' divided by cover 'rii'
  for (int i = 0; i < nrow; i++) {
    // double s = 0;
    for (int j = 0; j < ncol; j++) {
      // normal
      por(i,j) = par(i,j) / rii(i,j);
    }
  }

  // could be faster with Armadillo
  // por = armaMatDiv(par, rii)


  ncolt = 0;

  // variance! (by column!)
  for (int j = 0; j < ncol; j++) {
    double m = 0; // mean
    double s = 0; // sum
    double SoS = 0; // sum of squares
    int nas = 0; // counter for NA values

    // first calculate row means m
    // to deal with NA, NaN and infinite values
    // https://stackoverflow.com/questions/26241085/rcpp-function-check-if-missing-value
    for (int i = 0; i < nrow; i++) {
      // remove infinite values! (susbstitute with NaN)
      if (Rcpp::traits::is_infinite<REALSXP>(por(i,j))) {
        por(i,j) = R_NaN;
      }

      if (ISNAN(por(i,j))) {
        nas++;
      } else {
        s += por(i,j);
      }
    }

    // mean PoR ratio
    m = s/(nrow-nas);

    // riii: squared distance of PoR from its mean
    riii(_,j) = (por(_,j) - m) * (por(_,j) - m);

    // sum up the squares
    for (int i = 0; i < nrow; i++){
      if (!ISNAN(por(i,j))) {
        SoS += riii(i,j);
      }
    }

    double sd = 0;

    // only with at least one value per taxon:
    // calculate standard deviation
    if (nrow - 1 - nas > 0){
      ncolt += 1; // count this taxon
      sd = sqrt(SoS / (nrow - 1 - nas));
    }


    // normalize PoR ratio ( to mean = 0 and sd = 1)
    pornorm(_,j) = ((por(_,j) - m) / sd);


    // running mean
    vec = pornorm(_,j);

    for (int i = 0; i < (nrow-20); i++) {

      s = 0; // sum
      int n = 0; // number of occurrences

      for (int z = 0; z < 20; z++) {
        if (!ISNAN(pornorm(i+z, j))) {
          s += pornorm(i+z, j);
          n += 1;
        }
      }

      // wenn weniger als 2 Werte im Abschnitt- mean = 0
      // zählt dann in der Summe nicht mit
      if (n > 2){
        vm(i) = s / n;
      } else {
        vm(i) = 0;
      }
    }

    var(j) = sum(abs(vm));

  }


  return sum(var);
}
