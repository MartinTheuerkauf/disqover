#' Needed from Rcpp
#'
#'
#' @description Some commands needed for Rcpp, could be somewhere else?
#'
## usethis namespace: start
#' @useDynLib disqover, .registration = TRUE
## usethis namespace: end
NULL


## usethis namespace: start
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL


#'
#' local pollen data for MarcoPolo example
#'
#' One of 4 files of the MarcoPolo example data set used in Mrotzek A., Couwenberg J., Theuerkauf M. and Joosten H. (2017) MARCO POLO – A new and simple tool for pollen-based stand-scale vegetation reconstruction. The Holocene 27: 321-330. DOI:10.1177/0959683616660171
#'
#' @docType data
#' @keywords datasets
#' @name localMP
#' @usage data("MP_example", package = "disqover")
#' @format A dataframe with 14 rows (= pollen types) and 11 variables (= local sample sites)
NULL


#'
#' regional pollen data for MarcoPolo example
#'
#' One of 4 files of the MarcoPolo example data set used in Mrotzek A., Couwenberg J., Theuerkauf M. and Joosten H. (2017) MARCO POLO – A new and simple tool for pollen-based stand-scale vegetation reconstruction. The Holocene 27: 321-330. DOI:10.1177/0959683616660171
#'
#' @docType data
#' @keywords datasets
#' @name regionalMP
#' @usage data("MP_example", package = "disqover")
#' @format A dataframe with 14 rows (= pollen types) and 3 variables (= regional sample sites)
NULL


#'
#' Link between local and regional pollen data for MarcoPolo example
#'
#' One of 4 files of the MarcoPolo example data set used in Mrotzek A., Couwenberg J., Theuerkauf M. and Joosten H. (2017) MARCO POLO – A new and simple tool for pollen-based stand-scale vegetation reconstruction. The Holocene 27: 321-330. DOI:10.1177/0959683616660171
#'
#' @docType data
#' @keywords datasets
#' @name assignmentMP
#' @usage data("MP_example", package = "disqover")
#' @format A dataframe with 11 rows (= sample sites) and 2 variables (= local and regional sample sites)
NULL


#'
#' R values for MarcoPolo example
#'
#' One of 4 files of the MarcoPolo example data set used in Mrotzek A., Couwenberg J., Theuerkauf M. and Joosten H. (2017) MARCO POLO – A new and simple tool for pollen-based stand-scale vegetation reconstruction. The Holocene 27: 321-330. DOI:10.1177/0959683616660171
#'
#' @docType data
#' @keywords datasets
#' @name paramsMP
#' @usage data("MP_example", package = "disqover")
#' @format A dataframe with 14 rows (= pollen types) and 2 variables (= R-values)
NULL


#'
#' Parameter for REVEALS examples
#'
#' Example data for REVEALSinR
#'
#' \itemize{
#'   \item species. plant taxon
#'   \item fallspeed. fall speed of pollen
#'   \item PPEs. Pollen productivty estimates (Sourece??)
#'   \item PPE.error. Standard error of PPEs.
#' }
#' @docType data
#' @keywords datasets
#' @name paramsTS
#' @usage data("MP_example", package = "disqover")
#' @format A dataframe with 14 rows (= pollen types) and 2 variables (= R-values)
NULL


#'
#' Pollen data for REVEALS examples
#'
#' Example data for REVEALSinR
#'
#' \itemize{
#'   \item Age_AD_BC. Age in calendar years
#'   \item Acer. First pollen type....
#' }
#' @docType data
#' @keywords datasets
#' @name pollenTS
#' @usage data("MP_example", package = "disqover")
#' @format A dataframe with 14 rows (= pollen types) and 2 variables (= R-values)
NULL


#'
#' Pollen data for REVEALS examples
#'
#' Example data for REVEALSinR
#'
#' @docType data
#' @keywords datasets
#' @name eda_tc17c
#' @usage data("eda_tc17c", package = "disqover")
#' @format A list with 4 elements: pollen data, environmental data, parameter, radii
NULL

## quiets concerns of R CMD check re: the .'s that appear in pipelines
## from: https://stackoverflow.com/questions/9439256/how-can-i-handle-r-cmd-check-no-visible-binding-for-global-variable-notes-when
if(getRversion() >= "2.15.1")  utils::globalVariables(c("."))
