#include <Rcpp.h>
using namespace Rcpp;

// This is a simple example of exporting a C++ function to R. You can
// source this function into an R session using the Rcpp::sourceCpp
// function (or via the Source button on the editor toolbar). Learn
// more about Rcpp at:
//
//   http://www.rcpp.org/
//   http://adv-r.had.co.nz/Rcpp.html
//   http://gallery.rcpp.org/
//

//' calculate distance between true and modelled pollen for optimization
//' @param alpha random starting value, automically provided
//' @export
// [[Rcpp::export]]

double distmean(NumericVector alpha) {

  Environment e = Environment::global_env();
  Rcpp::NumericMatrix par = e["parf"];
  Rcpp::NumericMatrix pc = e["pcf"];
  Rcpp::NumericVector k = e["k"];
  String wopt = e["wopt"];

  int nrow = par.nrow(), ncol = par.ncol();
  Rcpp::NumericMatrix por(nrow, ncol);
  Rcpp::NumericMatrix ri(nrow, ncol);
  Rcpp::NumericMatrix rii(nrow, ncol);
  Rcpp::NumericMatrix porm(nrow, ncol);
  Rcpp::NumericVector var = ncol;
  Rcpp::NumericVector mcov = ncol; // mean cover of each species
  Rcpp::NumericVector csum = ncol; // mean counts of each species

  // ri - divide counts by PPE and K
  Rcpp::NumericVector f = alpha * k;
  for (int i = 0; i < nrow; i++) {
    ri(i,_) = pc(i,_) / f;
  }


  // rii - calculate proportions (=REVEALS)
  // loop of rows
  // first calculate rowsum
  // then divide row values by rowsum
  for (int i = 0; i < nrow; i++) {
    double s = 0;
    for (int j = 0; j < ncol; j++) {
      s += ri(i,j);
    }
    rii(i,_) = ri(i,_) / s;
  }

  // calculate mean cover of each species
  // might be useful for weighting
  // by the way also add up counts
  for (int j = 0; j < ncol; j++) {
    double s = 0;
    for (int i = 0; i < nrow; i++) {
      s += rii(i,j);        // sum up cover
      csum(j) += pc(i,j);  // sum up counts
    }
    mcov(j) = s/nrow; // mean cover
  }


  // calculate PoR and mean PoR ratio
  // i.e. divide PoR by mean of each taxon
  for (int j = 0; j < ncol; j++) {

    double s = 0;
    double m = 0;
    int nas = 0;
    double x =0;

    // calculate PoR for each species and samples
    for (int i = 0; i < nrow; i++) {
      x = par(i,j) / rii(i,j);

      // handle infinite values
      if (Rcpp::traits::is_infinite<REALSXP>(x)) {
        x = R_NaN;
      }
      if (ISNAN(x)) {
        nas++;
      } else {
        s += x;
      }
      por(i,j) = x;
    }

    // calculate mean PoR ratio of each species
    m = s /(nrow-nas);

    // new options (package 9.05)
    // are NA values treated correctly?
    if (wopt == "no") porm(_,j) = por(_,j);
    else if (wopt == "counts") porm(_,j) = por(_,j) * csum(j);
    else if (wopt == "sqrt.counts") porm(_,j) = por(_,j) * sqrt(csum(j));
    else if (wopt == "cover") porm(_,j) = por(_,j) * mcov(j);
    else if (wopt == "por") porm(_,j) = por(_,j) / m;
    else if (wopt == "sqrt") porm(_,j) = sqrt(por(_,j));
  }


  // calculate mean PoRm
  Rcpp::NumericVector m(nrow);

  for (int i = 0; i < nrow; i++) {

    double s = 0;
    int nas = 0;
    double x = 0;

    for (int j = 0; j < ncol; j++){
      x = porm(i,j);
      if (ISNAN(x)) {
        nas++;
      } else {
        s += x;
      }
    }
    m(i) = s/(ncol-nas);
  }

  return Rcpp::var(m);
}
